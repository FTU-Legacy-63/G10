import '@fontsource/noto-sans/latin-400.css';
import '@fontsource/noto-sans/latin-600.css';
import '@fontsource/noto-sans/vietnamese-400.css';
import '@fontsource/noto-sans/vietnamese-600.css';
import './styles/game.css';
import './styles/world.css';
import './styles/spatial.css';
import './styles/pointclick.css';
export { default } from './App';
