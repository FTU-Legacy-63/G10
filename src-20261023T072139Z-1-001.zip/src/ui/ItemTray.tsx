import { CASES, WAREHOUSE } from '../content';
import { currentCopies, selectedCopy } from '../application/objectActions';
import { ROOM_COPY } from '../game/roomArt';
import type { View } from '../domain/types';
import type { Game } from './types';

export function ItemTray({ game, onOpen }: { game: Game; onOpen: (view: View) => void }) {
  const copies = currentCopies(game.state), selected = selectedCopy(game.state);
  const carried = copies.filter(copy => copy.location === 'inventory');
  const locked = game.state.phase === 'submitted';
  const file = CASES[game.state.current];
  return <aside className={`item-tray ${selected ? 'item-selected' : ''}`} aria-label="Working copies">
    <div className="tray-caption"><strong>Copies</strong><span>{file.id}</span></div>
    <div className="carried-items" aria-label="Carried copies">
      {!carried.length ? <p className="empty-tray">Take a selected record from the terminal to carry a copy.</p> : carried.map(copy => {
        const record = WAREHOUSE.find(record => record.id === copy.recordId)!;
        return <button key={copy.id} className={`inventory-copy ${copy.id === selected?.id ? 'selected' : ''}`} aria-pressed={copy.id === selected?.id} aria-label={`Select copy ${copy.recordId} · ${record.name}`} onClick={() => game.send({ type: 'object', action: { kind: 'select-copy', copyId: selected?.id === copy.id ? null : copy.id } })}><img src={ROOM_COPY.states.carried} alt="" /><span><strong>{copy.recordId}</strong><small>{record.name}</small></span></button>;
      })}
    </div>
    {selected ? <div className="item-actions" aria-label={`Use selected copy ${selected.recordId}`}><span role="status">Selected: <strong>{selected.recordId}</strong></span><button disabled={locked} onClick={() => game.useCopy?.('desk')}>Place on desk</button><button disabled={locked} onClick={() => game.useCopy?.('board')}>Pin to board</button><button onClick={() => game.inspectCopy?.(selected.recordId)}>Read copy</button><button disabled={locked} onClick={() => game.send({ type: 'object', action: { kind: 'return-copy', copyId: selected.id } })}>Return copy</button><button aria-label="Cancel item selection" onClick={() => game.send({ type: 'object', action: { kind: 'select-copy', copyId: null } })}>Cancel</button></div> : <div className="placed-items">{copies.filter(copy => copy.location !== 'inventory').map(copy => <button key={copy.id} onClick={() => copy.location === 'board' ? onOpen('board') : game.inspectCopy?.(copy.recordId)}>{copy.recordId}<small>{copy.location === 'board' ? 'On board' : 'On desk'}</small></button>)}{!copies.length ? <button onClick={() => onOpen('warehouse')}>Use terminal</button> : null}</div>}
  </aside>;
}
