import type { RefObject } from 'react';
import { CASES } from '../content';
import { STATIONS, VIEW_LABEL } from '../game/spatial';
import { Arrow, CloseIcon } from './Primitives';
import { SourceWorkspace } from './SourceWorkspace';
import { WarehouseView } from './WarehouseView';
import { BoardView } from './BoardView';
import { RulebookView } from './RulebookView';
import { ReviewView } from './ReviewView';
import { SummaryView } from './SummaryView';
import { DecisionPanel } from './DecisionPanel';
import { ReadingPane } from './ReadingPane';
import { artForView, objectState } from '../game/roomState';
import type { Game } from './types';

export function WorkObject({ game, heading, backLabel, onBack, onClose, onSubmit, onRestart }: { game: Game; heading: RefObject<HTMLHeadingElement | null>; backLabel: string; onBack: () => void; onClose: () => void; onSubmit: () => void; onRestart: () => void }) {
  const { state } = game;
  if (state.view === 'office') return null;
  const view = state.view, file = CASES[state.current];
  const deskFile = view === 'dossier' || view === 'worksheet';
  const art = artForView(view), visualState = objectState(state, art.id);
  const coverClosed = view === 'dossier' && !game.copyOnDesk && !state.objects.folderOpen[file.id];
  return <section className={`work-object view-${view} station-${STATIONS[view]}`} aria-label="Work area">
    <div className="object-toolbar"><button className="object-back" onClick={onBack}><Arrow left />{backLabel}</button><span className="in-use-object"><img src={art.states[visualState]} alt="" />{VIEW_LABEL[view]}</span><div className="object-close-actions">{view === 'dossier' && !game.copyOnDesk ? <button onClick={() => game.send({ type: 'object', action: { kind: 'folder', open: coverClosed } })}>{coverClosed ? 'Open cover' : 'Close cover'}</button> : null}<button className="object-close" aria-label="Put down and return to office" onClick={onClose}><CloseIcon /><span>Put down</span></button></div></div>
    <div className={`object-housing ${view === 'warehouse' ? 'monitor-housing' : view === 'help' ? 'rulebook-housing' : view === 'board' ? 'pinboard-housing' : view === 'review' || view === 'summary' ? 'ledger-housing' : 'folder-housing'}`}>
      {view === 'warehouse' ? <div className="terminal-systembar"><span className="terminal-pixel" aria-hidden="true" />Income Verification Warehouse<span>Branch records</span></div> : null}
      <div className="object-context"><div><h2 ref={heading} tabIndex={-1}>{view === 'summary' ? 'Final round report' : state.started ? file.name : 'Credit rulebook'}</h2><span className="fine">{view === 'summary' ? 'Read-only · all eight dossiers' : state.started ? `${file.id} · ${file.age} · ${file.province}` : 'Assessment guide'}</span></div><span className="macro">Macro environment <strong>Normal</strong></span></div>
      <ReadingPane game={game} id={`surface:${view}:${file.id}:${state.dossierTabs[file.id]}:${state.deskCopy ?? ''}:${state.objects.terminalPage}:${state.objects.notebookPage}`} className={`object-interior ${deskFile && !coverClosed ? 'with-decision' : ''}`}>
        {coverClosed ? <button className="folder-cover" onClick={() => game.send({ type: 'object', action: { kind: 'folder', open: true } })}><img src={art.states.closed} alt="Closed application folder" /><strong>{file.id} · {file.name}</strong><span>Open application folder</span></button> : <>
        <ReadingPane game={game} id={`${view}:${file.id}:outer`} className="object-reading">
          {deskFile ? <SourceWorkspace game={game} /> : null}
          {view === 'warehouse' ? <WarehouseView game={game} /> : null}
          {view === 'board' ? <BoardView game={game} /> : null}
          {view === 'help' ? <RulebookView game={game} /> : null}
          {view === 'review' ? <ReviewView game={game} onSubmit={onSubmit} /> : null}
          {view === 'summary' ? <SummaryView game={game} onRestart={onRestart} /> : null}
        </ReadingPane>
        {deskFile && state.started ? <DecisionPanel key={file.id} game={game} /> : null}
        </>}
      </ReadingPane>
      {view === 'warehouse' ? <div className="monitor-chin"><span>WAREHOUSE TERMINAL</span><span className="monitor-power" aria-hidden="true" /></div> : null}
    </div>
    {view === 'warehouse' ? <div className="terminal-stand" aria-hidden="true" /> : null}
  </section>;
}
