import { CASES } from '../content';
import { DossierView } from './DossierView';
import { NotebookView } from './NotebookView';
import { ReadingPane } from './ReadingPane';
import type { Game } from './types';
import { PaperCopy } from './PaperCopy';

export function SourceWorkspace({ game }: { game: Game }) {
  const { state, send } = game;
  const file = CASES[state.current];
  const notebook = state.view === 'worksheet';
  return <div className={`source-workspace ${notebook ? 'notebook-open' : ''}`}>
    <div className="workspace-switch" aria-label="Source and worksheet">
      <button aria-pressed={!notebook} onClick={() => send({ type: 'view', view: 'dossier' })}>Source documents</button>
      <button aria-pressed={notebook} onClick={() => send({ type: 'view', view: 'worksheet' })}>Notebook</button>
    </div>
    <div className="workspace-source">{game.copyOnDesk ? <div className="dossier-content"><div className="document-tabs"><button onClick={() => game.inspectCopy?.(null)}>Return to application</button><button aria-pressed="true">Evidence copy · {game.copyOnDesk}</button></div><ReadingPane game={game} id={`copy:${game.copyOnDesk}`} className="dossier-page" label="Evidence copy reading pane"><PaperCopy game={game} id={game.copyOnDesk} /></ReadingPane></div> : <DossierView game={game} />}</div>
    <ReadingPane game={game} id={`worksheet:${file.id}:${state.objects.notebookPage}`} className="workspace-notebook" label="Worksheet reading pane"><NotebookView game={game} /></ReadingPane>
  </div>;
}
