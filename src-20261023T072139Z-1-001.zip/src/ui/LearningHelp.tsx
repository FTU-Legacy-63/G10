import type { Game } from './types';

/** Public definitions only. No answer key, computed reference or source-match inference. */
export const FIELD_HELP: Record<string, { text: string; chapter: string }> = {
  character: { text: 'Character uses CIC credit history and documentary authenticity. A difference in income alone is not forgery.', chapter: 'Apply the rules in order' },
  purpose: { text: 'Compare the stated use and amount with the supporting documents.', chapter: 'Apply the rules in order' },
  acceptance: { text: 'For a secured loan, check whether the proposed asset can legally be accepted as security.', chapter: 'Apply the rules in order' },
  dti: { text: 'DTI is debt-to-income ratio: (existing monthly debt payments + the requested installment) ÷ verified eligible monthly income × 100. Household living costs are not debt payments.', chapter: 'Evidence & your working' },
  net: { text: 'Net collateral is the appraised value minus outstanding senior claims. Use the documented values.', chapter: 'Apply the rules in order' },
  ltv: { text: 'LTV is loan-to-value ratio: assessed principal ÷ net collateral × 100. Consult the rules for which principal applies.', chapter: 'Apply the rules in order' },
  collateral: { text: 'Assess both acceptance of the security and the loan-to-value requirement. An unsecured file has no collateral check.', chapter: 'Apply the rules in order' },
  reserve: { text: 'Reserve cover is eligible liquid assets ÷ monthly debt service, measured in months. Read the eligibility rules before counting assets.', chapter: 'Apply the rules in order' },
  capital: { text: 'Capital describes the borrower’s eligible liquid reserve cover. Real estate is not a liquid reserve.', chapter: 'Apply the rules in order' },
  conditions: { text: 'Conditions describe the main-income industry and macro environment. They do not change the DTI thresholds.', chapter: 'Apply the rules in order' },
};

export function LearningHelp({ game, title, text, chapter }: { game: Game; title: string; text: string; chapter: string }) {
  if (!game.learning) return null;
  return <details className="learning-help"><summary>{title}</summary><p>{text}</p><button type="button" aria-label={`Read ${title} in the rulebook`} onClick={() => game.learning?.openGuide(chapter)}>Read this rule in the book</button></details>;
}
