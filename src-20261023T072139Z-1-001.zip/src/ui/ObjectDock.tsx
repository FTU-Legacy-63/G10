import type { View } from '../domain/types';
import { TaskIcon } from './TaskIcon';
const OBJECTS: { view: View; label: string; kind: string }[] = [
  { view: 'dossier', label: 'Folder', kind: 'folder' }, { view: 'worksheet', label: 'Notebook', kind: 'notebook' },
  { view: 'warehouse', label: 'Terminal', kind: 'terminal' }, { view: 'board', label: 'Board', kind: 'board' },
  { view: 'review', label: 'Ledger', kind: 'ledger' }, { view: 'help', label: 'Rulebook', kind: 'book' },
];
export function ObjectDock({ view, submitted, onOpen }: { view: View; submitted: boolean; onOpen: (view: View) => void }) {
  return <nav className="object-dock" aria-label="Objects within reach">{OBJECTS.map(object => <button key={object.view} className={`dock-object dock-${object.kind} ${view === object.view ? 'in-hand' : ''}`} aria-current={view === object.view ? 'page' : undefined} aria-label={`Open ${object.label.toLowerCase()}`} onClick={() => onOpen(object.view)}><span className="dock-cover"><TaskIcon view={object.view} /></span><span>{object.label}</span></button>)}{submitted ? <button className={`dock-object dock-report ${view === 'summary' ? 'in-hand' : ''}`} aria-label="Open final report" onClick={() => onOpen('summary')}><span className="dock-cover"><TaskIcon view="summary" /></span><span>Report</span></button> : null}</nav>;
}
