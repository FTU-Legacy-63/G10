import { useMemo, useState } from 'react';
import { CASES, WAREHOUSE } from '../content';
import { searchError, searchRecords } from '../domain/search';
import { currentCopies } from '../application/objectActions';
import { CicView } from './CicView';
import { EvidenceText } from './EvidenceText';
import type { Game } from './types';
import { ReadingPane } from './ReadingPane';
const PROVINCES = [...new Set(WAREHOUSE.map(r => r.province))].sort((a, b) => a.localeCompare(b, 'vi'));
export function WarehouseView({ game }: { game: Game }) {
  const { state, send } = game;
  const file = CASES[state.current];
  const draft = state.drafts[file.id];
  const [submitted, setSubmitted] = useState(!!state.query.name);
  const [showSearch, setShowSearch] = useState(!state.query.name);
  const [form, setForm] = useState(state.query);
  const [touched, setTouched] = useState(false);
  const error = searchError(form);
  const results = useMemo(() => searchRecords(WAREHOUSE, state.query, state.seed), [state.query, state.seed]);
  const selected = WAREHOUSE.find(r => r.id === state.selectedRecord);
  const physicalCopy = currentCopies(state).find(copy => copy.recordId === selected?.id);
  const page = state.objects.terminalPage;
  const patch = (value: Partial<typeof form>) => setForm(old => ({ ...old, ...value }));
  return <div className={`warehouse-content terminal-page-${page}`}>
    <nav className="terminal-pages" aria-label="Terminal services"><button aria-pressed={page === 'warehouse'} onClick={() => send({ type: 'object', action: { kind: 'terminal-page', page: 'warehouse' } })}>Warehouse · 168 records</button><button aria-pressed={page === 'cic'} onClick={() => send({ type: 'object', action: { kind: 'terminal-page', page: 'cic' } })}>CIC · current applicant</button></nav>
    {page === 'cic' ? <ReadingPane game={game} id={`terminal-cic:${file.id}`} className="terminal-cic-reader" label="CIC document"><CicView game={game} /></ReadingPane> : <>
    {submitted ? <div className="search-summary"><span><strong>{state.query.name}</strong>{state.query.age ? ` · ${state.query.age}` : ''}{state.query.province ? ` · ${state.query.province}` : ''}</span><button aria-expanded={showSearch} onClick={() => setShowSearch(value => !value)}>{showSearch ? 'Hide filters' : 'Edit search'}</button></div> : null}
    {showSearch ? <form className="search-form" onSubmit={e => { e.preventDefault(); setTouched(true); if (!error) { send({ type: 'query', value: form }); setSubmitted(true); setShowSearch(false); send({ type: 'record', id: null }); } }}>
      <div className="search-fields"><label className="field name-field"><span>Name <span className="fine">required</span></span><input autoComplete="off" maxLength={100} name="search-name" value={form.name} onChange={e => patch({ name: e.target.value })} aria-describedby={touched && error ? 'search-error' : undefined} /></label>
        <label className="field">Age or range<input name="search-age" maxLength={30} placeholder="35 or 30-40" value={form.age} onChange={e => patch({ age: e.target.value })} /></label>
        <label className="field">Province<select name="search-province" value={form.province} onChange={e => patch({ province: e.target.value })}><option value="">Any province</option>{PROVINCES.map(p => <option key={p}>{p}</option>)}</select></label>
        <button className="primary" type="submit">Search</button>
      </div>
      <div className="search-options"><label><input type="checkbox" checked={form.strict} onChange={e => patch({ strict: e.target.checked })} />Match diacritics exactly</label><label><input type="checkbox" checked={form.fuzzy} onChange={e => patch({ fuzzy: e.target.checked })} />Allow one character difference per word</label></div>
      {touched && error ? <p id="search-error" className="field-error" role="alert">{error}</p> : null}
    </form> : null}
    <div className="warehouse-split">
      <ReadingPane game={game} id={`results:${state.query.name.slice(0, 60)}:${state.query.age}:${state.query.province.slice(0, 30)}:${+state.query.strict}${+state.query.fuzzy}`} className="search-results" label="Warehouse results">
        <h3>{submitted ? `${results.length} ${results.length === 1 ? 'record' : 'records'} found` : 'Income verification directory'}</h3>
        {!submitted ? <p className="muted">Search the shared directory of 168 records. Open documents and compare identity details before choosing a record.</p> : results.length === 0 ? <p className="muted">No records found. Try a wider name search or remove an optional filter.</p> : <ul>{results.map(record => <li key={record.id}><button className={selected?.id === record.id ? 'record-row selected' : 'record-row'} onClick={() => send({ type: 'record', id: record.id })} aria-pressed={selected?.id === record.id}><span className="record-id">{record.id}</span><strong>{record.name}</strong><span>{record.age} · {record.province}</span><span className="fine">{record.headline}</span></button></li>)}</ul>}
      </ReadingPane>
      <ReadingPane game={game} id={`warehouse:${state.selectedRecord ?? 'empty'}:doc`} className="record-document" label="Warehouse document">
        {selected ? <>
          <div className="document-heading"><div><span className="record-id">{selected.id}</span><h3>{selected.name}</h3><p className="muted">{selected.age} · {selected.province}</p></div><button className="text-button" onClick={() => send({ type: 'record', id: null })}>Close record</button></div>
          <p className="document-caption">{selected.headline}</p><EvidenceText game={game} sourceLabel={selected.id} text={selected.documents} />
          <div className="record-actions"><button className="primary" disabled={state.phase === 'submitted'} onClick={() => send({ type: 'draft', patch: { pin: selected.id } })}>{draft.pin === selected.id ? 'Attached to assessment' : 'Attach to assessment'}</button></div>
          <div className="copy-collection"><button className="take-copy" disabled={state.phase === 'submitted' || !!physicalCopy && physicalCopy.location !== 'inventory'} onClick={() => send({ type: 'object', action: { kind: 'take-copy', recordId: selected.id } })}>{physicalCopy ? physicalCopy.location === 'inventory' ? 'Select collected copy' : `Copy is on ${physicalCopy.location}` : 'Take a copy'}</button>{physicalCopy ? <><span className="fine" role="status">{selected.id} · collected for {file.id}; this does not confirm identity.</span><button className="text-button" onClick={() => game.inspectCopy?.(selected.id)}>Read collected copy</button></> : null}</div>
          {draft.pin === selected.id ? <p role="status" className="fine">{selected.id} is attached to {file.name}’s working.</p> : null}
        </> : <div className="empty-document"><h3>Open a record to read its documents</h3><p>Search results show identity and headline only. Attach a record to record your selection; you can change it until Submit.</p></div>}
      </ReadingPane>
    </div>
    {draft.pin ? <div className="pinned-strip"><span>Attached for {file.name}: <strong>{draft.pin}</strong></span><button className="text-button" disabled={state.phase === 'submitted'} onClick={() => send({ type: 'draft', patch: { pin: null } })}>Remove attachment</button></div> : null}
    </>}
  </div>;
}
