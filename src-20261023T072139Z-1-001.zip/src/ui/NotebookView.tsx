import { CASES } from '../content';
import { Worksheet } from './Worksheet';
import type { Game } from './types';

export function NotebookView({ game }: { game: Game }) {
  const file = CASES[game.state.current], page = game.state.objects.notebookPage;
  return <div className="notebook-pages"><nav aria-label="Notebook pages"><button aria-pressed={page === 'worksheet'} onClick={() => game.send({ type: 'object', action: { kind: 'notebook-page', page: 'worksheet' } })}>Worksheet</button><button aria-pressed={page === 'notes'} onClick={() => game.send({ type: 'object', action: { kind: 'notebook-page', page: 'notes' } })}>Personal notes</button></nav>{page === 'worksheet' ? <Worksheet game={game} /> : <div className="document-body notebook-notes"><h3>Personal notes</h3><p className="fine">Optional working for {file.name} · unscored</p><label className="field">Notes for {file.name}<textarea maxLength={20000} value={game.state.drafts[file.id].notes} disabled={game.state.phase === 'submitted'} onChange={e => game.send({ type: 'draft', patch: { notes: e.target.value } })} /></label><p className="fine">Source excerpts saved from the file or terminal appear here with attribution.</p><button onClick={() => game.send({ type: 'view', view: 'board' })}>Compare evidence on the board</button></div>}</div>;
}
