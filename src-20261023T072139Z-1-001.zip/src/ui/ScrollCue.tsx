import { useEffect, useState } from 'react';
import type { RefObject } from 'react';

/** Event-driven cue follows the visible lower edge of an existing scroll region. */
export function ScrollCue({ target, refresh }: { target: RefObject<HTMLElement | null>; refresh: string }) {
  const [top, setTop] = useState<number | null>(null);
  useEffect(() => {
    const node = target.current; if (!node) return;
    let alive = true;
    const update = () => {
      if (alive) setTop(node.scrollHeight - node.clientHeight - node.scrollTop > 18 ? node.scrollTop + node.clientHeight - 24 : null);
    };
    const observer = new ResizeObserver(update); observer.observe(node);
    if (node.firstElementChild) observer.observe(node.firstElementChild);
    node.addEventListener('scroll', update, { passive: true });
    const frame = requestAnimationFrame(update); void document.fonts.ready.then(update);
    return () => { alive = false; observer.disconnect(); node.removeEventListener('scroll', update); cancelAnimationFrame(frame); };
  }, [target, refresh]);
  return top === null ? null : <span className="learning-scroll-cue" style={{ top }} aria-hidden="true">More below ▾</span>;
}
