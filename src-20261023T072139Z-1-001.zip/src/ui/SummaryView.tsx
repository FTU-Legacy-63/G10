import { CASES } from '../content';
import { money, parseNumber, plannedAllocation } from '../domain/finance';
import { COVENANTS, WORKSHEET_FIELDS } from '../domain/types';
import { Paragraphs } from './Primitives';
import type { ReferenceResult } from '../domain/types';
import type { Game } from './types';
function referenceText(reference: ReferenceResult, key: string): string {
  const value = reference[key as keyof ReferenceResult];
  if (value === null) return key === 'reserve' && reference.reserveBasis.includes('awaits') ? 'Source review' : ['net', 'ltv'].includes(key) && reference.collateral === 'N/A' ? 'N/A' : 'Not assessed';
  if (typeof value === 'number') return ['dti', 'ltv'].includes(key) ? `${(value * 100).toFixed(2)}%` : key === 'reserve' ? `${value.toFixed(2)} months` : `${money(value)} VND`;
  return String(value);
}
interface SummaryViewProps {
  game: Game;
  onRestart: () => void;
  mode?: 'full' | 'overview' | 'detail';
  caseIndex?: number;
  onDetail?: (index: number) => void;
  physical?: boolean;
}
export function SummaryView({ game, onRestart, mode = 'full', caseIndex, onDetail, physical = false }: SummaryViewProps) {
  const { state } = game;
  if (state.phase !== 'submitted') return null;
  if (!state.snapshot) return <p className="document-body" role="status">Rebuilding your saved report…</p>;
  const allocated = CASES.reduce((sum, file) => sum + (plannedAllocation(state.drafts[file.id], file) ?? 0), 0);
  const conditional = CASES.filter(file => ['Require more collateral', 'Add conditions'].includes(state.drafts[file.id].decision!)).reduce((sum, file) => sum + file.principal, 0);
  const selectedIndex = caseIndex !== undefined && Number.isInteger(caseIndex) && caseIndex >= 0 && caseIndex < CASES.length ? caseIndex : state.current;
  return <div className="document-body summary-view">
    <div className="report-heading"><div><p className="final-stamp">Submitted</p><h3>{mode === 'detail' ? 'Dossier assessment' : 'Summary Consequence Card'}</h3><p>Your final choices and the evidence behind each classification.</p></div><button onClick={game.downloadSave}>Export progress</button></div>
    <p className="report-note">This shift is complete and read-only. Seven files have reference comparisons; one reference is held for source review. Worksheet entries and covenant selections are unscored.</p>
    {mode !== 'detail' ? <section className="portfolio-result" aria-labelledby="portfolio-result"><h4 id="portfolio-result">Result · your portfolio</h4><div className="ledger-totals"><div><span>Planned allocation</span><strong>{money(allocated)} VND</strong></div><div><span>Round room</span><strong>4,590,000,000 VND</strong></div><div><span>{allocated > 4590e6 ? 'Over by' : 'Remaining'}</span><strong>{money(Math.abs(4590e6 - allocated))} VND</strong></div></div><p className="fine">{money(conditional)} VND of the planned allocation is conditional on collateral or covenants. These are simulated planned offers under the current allocation model, not issued commitments. No portfolio risk or weighted score is calculated.</p></section> : null}
    <h4>Reason · dossier assessments</h4>
    {mode === 'overview' ? <div className="cs-report-overview-table"><table className="ledger-table">
      <caption className="cs-report-table-caption">Eight finalized dossiers · open a row to read its assessment</caption>
      <thead><tr><th>Applicant</th><th>Your final decision</th><th>Reference decision</th><th>Comparison</th><th>Detail</th></tr></thead>
      <tbody>{state.snapshot.reports.map((report, index) => {
        const file = CASES[index];
        return <tr key={file.id}>
          <th scope="row"><span className="record-id">{file.id}</span>{file.name}</th>
          <td>{state.drafts[file.id].decision}</td>
          <td>{report.reference.decision ?? 'Held for source review'}</td>
          <td>{report.categoryMatches === null ? 'Reference under review' : report.categoryMatches ? 'Decision matches' : 'Decision differs'}</td>
          <td><button type="button" disabled={!onDetail} onClick={() => onDetail?.(index)} aria-label={`Read assessment for ${file.id} · ${file.name}`}>Read assessment</button></td>
        </tr>;
      })}</tbody>
    </table></div> : state.snapshot.reports.map((report, i) => {
      if (mode === 'detail' && i !== selectedIndex) return null;
      const file = CASES[i];
      const draft = state.drafts[file.id];
      const r = report.reference;
      return <details key={file.id} className="case-report" open={mode === 'detail' || i === 0}>
        <summary><span><span className="record-id">{file.id}</span><strong>{file.name}</strong></span><span>{report.categoryMatches === null ? 'Reference under review' : report.categoryMatches ? 'Decision matches' : 'Decision differs'}</span></summary>
        <div className="case-report-content">
          <dl className="facts"><div><dt>Your final decision</dt><dd>{draft.decision}</dd></div>{draft.amount ? <div><dt>Your entered amount</dt><dd>{draft.amount} {draft.decision === 'Reduce limit' ? 'VND/month' : 'VND'}</dd></div> : null}
            <div><dt>Reference decision</dt><dd>{r.decision ?? 'Held for source review'}</dd></div>
            {draft.decision === 'Add conditions' ? <div><dt>Your covenant selection · unscored</dt><dd>{COVENANTS.filter(c => draft.covenants.includes(c.id)).map(c => c.label).join('; ')}</dd></div> : null}
            <div><dt>Your assessment record</dt><dd>{draft.pin ?? 'No record used'}</dd></div><div><dt>Main evidence record</dt><dd>{r.mainRecord}</dd></div>
          </dl>
          {draft.pin !== r.mainRecord ? <p className="report-note">{draft.pin ? 'The pinned record differs from the authored main record.' : 'No record was attached.'} The credit reference uses the applicant’s authored main evidence. No separate attachment penalty is applied.</p> : null}
          {r.reviewIssue ? <p className="report-note">{r.reviewIssue}</p> : <>
            <div className="reference-grid"><div><span>Verified eligible income</span><strong>{money(r.income)} VND/month</strong></div><div><span>Existing obligations</span><strong>{money(r.obligations)} VND/month</strong></div><div><span>Requested installment</span><strong>{money(file.emi)} VND/month</strong></div><div><span>Adjusted tenor</span><strong>{file.appliedMonths} months</strong></div><div><span>Annual interest rate</span><strong>{Math.round(file.annualRate * 100)}%</strong></div></div>
            {report.numericComparison ? <p>{report.numericComparison} · Reference: {money((draft.decision === 'Reduce limit' ? r.maxInstallment : r.additional)!)} {draft.decision === 'Reduce limit' ? 'VND/month' : 'VND'}</p> : null}
            {r.decision === 'Reduce limit' && r.proposedPrincipal !== null ? <p>Reference proposed principal: {money(r.proposedPrincipal)} VND. {r.reserveBasis}</p> : null}
            {r.decision === 'Require more collateral' && r.net !== null ? <p>Mathematical additional collateral: {money(file.principal / .7 - r.net)} VND. Comparison reference: {money(r.additional!)} VND, rounded up to the next million. Alternative maximum loan by collateral: {money(.7 * r.net)} VND.</p> : null}
            {r.secondary.length ? <div><h4>Secondary requirements</h4><ul>{r.secondary.map(item => <li key={item}>{item}</li>)}</ul></div> : null}
            <h4>Your worksheet & reference assessment</h4><table className="comparison-table"><thead><tr><th>Check</th><th>Your working</th><th>Reference</th></tr></thead><tbody>{WORKSHEET_FIELDS.map(field => {
              const raw = draft.worksheet[field.id];
              if ('secured' in field && file.product === 'Unsecured') return <tr key={field.id}><th scope="row">{field.label}</th><td>Not applicable</td><td>Not applicable</td></tr>;
              return <tr key={field.id}><th scope="row">{field.label}</th><td>{!raw.trim() ? 'Not answered' : 'numeric' in field && parseNumber(raw) === null ? `${raw} · Not comparable` : raw}</td><td>{referenceText(r, field.id)}</td></tr>;
            })}</tbody></table>
            <div className="consequence-text"><h4>Meaning · consequence & explanation</h4><Paragraphs text={report.consequence} /></div>
          </>}
          {draft.notes ? <div><h4>Your notes</h4><p className="saved-notes">{draft.notes}</p></div> : null}
        </div>
      </details>;
    })}
    {mode !== 'detail' && physical ? <p>Read each dossier assessment below. Put down the ledger to revisit source documents in the office. This report stays available until you start a new shift from the title screen.</p> : mode !== 'detail' ? <><h4>Action</h4><p>Read each assessment, reopen source documents using the task menu, or export this report's saved working. The finalized report remains available until you replace this attempt.</p>
    <div className="review-actions"><button onClick={onRestart}>Start a new shift</button><p className="fine">A new shift replaces this saved attempt. Export it first if you want to keep a copy.</p></div></> : null}
    <h4>Limit · Classification, not Recommendation</h4><p className="fine">Thresholds follow the supplied project rules and assumptions. Case 04's income/tax basis and Case 05's reserve denominator remain under source review. The room allocation model is provisional; no decision-accuracy percentage, portfolio risk score or room-efficiency score is supplied.</p>
  </div>;
}
