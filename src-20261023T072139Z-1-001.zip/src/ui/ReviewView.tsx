import { CASES } from '../content';
import { money, plannedAllocation, validateDecision } from '../domain/finance';
import { roundReady } from '../application/round';
import type { Game } from './types';
export function ReviewView({ game, onSubmit, physical = false, reception = false }: { game: Game; onSubmit: () => void; physical?: boolean; reception?: boolean }) {
  const { state, send } = game;
  const reached = CASES.slice(0, state.reached);
  const allocations = reached.map(file => plannedAllocation(state.drafts[file.id], file));
  const total = allocations.reduce<number>((sum, value) => sum + (value ?? 0), 0);
  const incomplete = allocations.some(a => a === null) || state.reached < CASES.length;
  const register = <>
    <h3>Round ledger</h3><p className="muted">Reopen any reached dossier to revise your working. Feedback appears together after you confirm Submit.</p>
    <div className="ledger-table-wrap"><table className="ledger-table"><caption className="sr-only">Reached dossiers and your provisional decisions</caption><thead><tr><th>Applicant</th><th>Your decision</th>{!physical && <th>Input</th>}<th>Planned allocation</th><th><span className="sr-only">Open dossier</span></th></tr></thead><tbody>
      {reached.map((file, i) => {
        const draft = state.drafts[file.id];
        const error = validateDecision(draft, file);
        const amount = allocations[i];
        return <tr key={file.id}><th scope="row"><span className="record-id">{file.id}</span>{file.name}<span className="fine">{file.age} · {file.province}</span></th><td>{draft.decision ?? 'Not chosen'}{physical && <span className={error ? 'readiness incomplete' : 'readiness'}>{error ? draft.decision ? 'Missing input' : 'Missing decision' : game.learning ? 'Required inputs complete' : 'Complete'}</span>}</td>{!physical && <td><span className={error ? 'readiness incomplete' : 'readiness'}>{error ? draft.decision ? 'Missing input' : 'Missing decision' : 'Structurally complete'}</span></td>}<td>{amount === null ? 'Incomplete' : `${money(amount)} VND`}{draft.decision === 'Require more collateral' || draft.decision === 'Add conditions' ? <span className="fine">Conditional</span> : null}</td><td><button onClick={() => send({ type: 'case', index: i })}>{state.phase === 'submitted' ? 'Read' : 'Review'}</button></td></tr>;
      })}
    </tbody></table></div>
    {state.reached < CASES.length ? <p className="fine">{CASES.length - state.reached} dossiers have not been opened. {physical || reception ? 'Receive the next application in the client room after completing the current decision.' : 'Save and continue from the latest dossier to reach the next one.'}</p> : null}
  </>;
  const totals = <>
    <div className="ledger-totals"><div><span>Planned so far{incomplete ? ' · incomplete' : ''}</span><strong>{money(total)} VND</strong></div><div><span>Round room</span><strong>4,590,000,000 VND</strong></div><div><span>{total > 4590e6 ? 'Over by' : 'Remaining'}</span><strong>{money(Math.abs(4590e6 - total))} VND</strong></div></div>
    <p className="fine">Planned amounts are based on your choices. Conditional offers remain subject to their conditions. Room overage does not block Submit.</p>
    <div className="review-actions">{state.phase === 'submitted' ? <button className="primary" onClick={() => send({ type: 'view', view: 'summary' })}>Open final Summary</button> : <button className="primary" disabled={!roundReady(state) || game.busy || game.stale} onClick={onSubmit}>Submit round</button>}
      {!roundReady(state) ? <p className="fine">Complete all dossiers before submitting. Blank worksheet fields and missing pins are allowed.</p> : <p className="fine">All required decisions and inputs are complete. You can keep reviewing for as long as you need.</p>}
    </div>
  </>;
  return <div className={`document-body review-view${physical ? ' discovery-ledger' : ''}`}>{physical ? <><section className="discovery-ledger-register">{register}</section><aside className="discovery-ledger-summary"><h3>Round room</h3>{totals}</aside></> : <>{register}{totals}</>}</div>;
}
