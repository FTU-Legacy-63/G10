import { Fragment } from 'react';
import { FIELD_HELP, LearningHelp } from './LearningHelp';
import { CASES } from '../content';
import { parseNumber } from '../domain/finance';
import { WORKSHEET_FIELDS } from '../domain/types';
import type { Game } from './types';
export function Worksheet({ game }: { game: Game }) {
  const { state, send } = game;
  const file = CASES[state.current];
  const draft = state.drafts[file.id];
  return <div className="document-body notebook-body">
    <h3>Your worksheet</h3><p className="muted">Optional and unscored. Blank fields are allowed.</p>
    <fieldset className="worksheet-grid">
      {WORKSHEET_FIELDS.filter(f => !('secured' in f) || file.product === 'Secured').map(field => {
        const value = draft.worksheet[field.id];
        const invalid = 'numeric' in field && !!value.trim() && parseNumber(value) === null;
        const control = <label className="field">{field.label}
          {'choices' in field ? <select disabled={state.phase === 'submitted'} value={value} onChange={e => send({ type: 'worksheet', field: field.id, value: e.target.value })}><option value="">Not answered</option>{field.choices.map(choice => <option key={choice}>{choice}</option>)}</select>
            : <input disabled={state.phase === 'submitted'} type="text" inputMode="decimal" maxLength={100} value={value} aria-invalid={invalid} aria-describedby={invalid ? `error-${field.id}` : undefined} onChange={e => send({ type: 'worksheet', field: field.id, value: e.target.value })} />}
          {invalid ? <span className="field-error" id={`error-${field.id}`}>Please enter a valid number or clear this optional field.</span> : null}
        </label>;
        return game.learning ? <div key={field.id} className="learning-field">{control}{FIELD_HELP[field.id] && <LearningHelp game={game} title={`About ${field.label}`} {...FIELD_HELP[field.id]} />}</div> : <Fragment key={field.id}>{control}</Fragment>;
      })}
    </fieldset>
    <p className="fine">Use 70 for 70%. Numbers use English formatting: 1,234.50 or 1234.50.</p>
    <p>Keep detailed reasoning in <button className="text-button" onClick={() => send({ type: 'view', view: 'board' })}>Comparison & notes</button>.</p>
  </div>;
}
