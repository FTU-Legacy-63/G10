import { useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
export function Arrow({ left = false }: { left?: boolean }) {
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true" style={left ? { transform: 'rotate(180deg)' } : undefined}><path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}
export function CloseIcon() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg>; }
export function Paragraphs({ text }: { text: string[] }) { return <div className="prose">{text.map((p, i) => <p key={i}>{p}</p>)}</div>; }
export function Dialog({ title, children, onClose, busy = false }: { title: string; children: ReactNode; onClose: () => void; busy?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  const close = useRef(onClose); close.current = onClose;
  useEffect(() => {
    const returnFocus = document.activeElement as HTMLElement | null;
    const dialog = ref.current!;
    dialog.showModal();
    return () => { dialog.close(); returnFocus?.isConnected && returnFocus.focus(); };
  }, []);
  return <dialog ref={ref} onCancel={event => { event.preventDefault(); if (!busy) close.current(); }} aria-labelledby="dialog-title" aria-busy={busy}>
    <div className="dialog-heading"><h2 id="dialog-title">{title}</h2><button className="icon-button" disabled={busy} onClick={onClose} aria-label="Close dialog"><CloseIcon /></button></div>
    {children}
  </dialog>;
}
