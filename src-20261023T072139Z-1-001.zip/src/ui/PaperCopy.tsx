import { CASES, WAREHOUSE } from '../content';
import { currentCopies } from '../application/objectActions';
import { EvidenceText } from './EvidenceText';
import type { Game } from './types';

export function PaperCopy({ game, id }: { game: Game; id: string }) {
  const record = WAREHOUSE.find(r => r.id === id);
  if (!record) return null;
  const file = CASES[game.state.current];
  const copy = currentCopies(game.state).find(copy => copy.recordId === id);
  return <article className="paper-copy document-body">
    <span className="copy-clip" aria-hidden="true" />
    <div className="copy-masthead"><span>WAREHOUSE · DOCUMENT COPY</span><span>{record.id}</span></div>
    <h3>{record.name}</h3><p className="document-caption">{record.age} · {record.province} · {record.headline}</p>
    <p className="fine">Collected for {file.id} · {file.name}</p>
    {game.learning && <p className="learning-copy-note">A copy is for reading at your desk or board. Attaching a record to the assessment is a separate action at the computer.</p>}
    <EvidenceText game={game} sourceLabel={record.id} text={record.documents} />
    <div className="copy-location"><span>Location: <strong>{copy?.location === 'inventory' ? 'Carried' : copy?.location === 'board' ? 'On board' : 'On desk'}</strong></span></div>
    <div className="record-actions">{copy ? <><button disabled={game.state.phase === 'submitted'} onClick={() => game.useCopy?.('board', undefined, copy.id)}>Pin copy to board</button>{copy.location !== 'inventory' ? <button disabled={game.state.phase === 'submitted'} onClick={() => game.send({ type: 'object', action: { kind: 'pick-up', copyId: copy.id } })}>Pick up copy</button> : <button disabled={game.state.phase === 'submitted'} onClick={() => game.useCopy?.('desk', undefined, copy.id)}>Place copy on desk</button>}</> : null}<button onClick={() => { game.send({ type: 'record', id }); game.send({ type: 'object', action: { kind: 'terminal-page', page: 'warehouse' } }); game.send({ type: 'view', view: 'warehouse' }); }}>Open original at terminal</button></div>
  </article>;
}
