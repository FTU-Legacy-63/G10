import type { View } from '../domain/types';

export function TaskIcon({ view }: { view: View }) {
  const paths: Record<View, string> = {
    office: 'M3 11 12 3l9 8M5 10v11h5v-7h4v7h5V10',
    dossier: 'M3 7h7l2-3h8l1 3v14H3V7Z',
    warehouse: 'm3 7 9-4 9 4-9 4-9-4Zm0 0v13l9 3 9-3V7M12 11v12',
    worksheet: 'M5 2h10l4 4v16H5V2Zm9 0v5h5M8 11h8M8 15h8M8 19h5',
    board: 'M8 4H4v18h16V4h-4M8 2h8v5H8V2ZM8 12h8M8 16h8',
    review: 'M4 3h16v19H4V3Zm4 0v19M11 8h6M11 12h6M11 16h6',
    help: 'M12 5C9 2 5 2 2 3v17c4-1 7 0 10 2m0-17c3-3 7-3 10-2v17c-4-1-7 0-10 2V5Z',
    summary: 'M5 2h14v20H5V2Zm3 6h8M8 12h8M8 16h5',
  };
  return <svg className="task-icon" width="23" height="24" viewBox="0 0 24 25" fill="none" aria-hidden="true"><path d={paths[view]} stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" /></svg>;
}
