import { useLayoutEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import { ScrollCue } from './ScrollCue';
import type { Game } from './types';

export function ReadingPane({ game, id, className = '', children, label }: { game: Game; id: string; className?: string; children: ReactNode; label?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const latest = useRef(game); latest.current = game;
  useLayoutEffect(() => {
    if (ref.current) ref.current.scrollTop = latest.current.state.scroll[id] ?? 0;
  }, [id]);
  return <div ref={ref} className={`reading-pane ${className}`} aria-label={label} tabIndex={label ? 0 : undefined} onScroll={event => {
    if (event.target !== event.currentTarget) return;
    const top = event.currentTarget.scrollTop;
    if (Math.abs((latest.current.state.scroll[id] ?? 0) - top) > 8) latest.current.send({ type: 'scroll', key: id, top });
  }}>{children}{game.learning && <ScrollCue target={ref} refresh={id} />}</div>;
}
