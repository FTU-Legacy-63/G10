import type { useGame } from '../application/useGame';
import type { Action } from '../application/round';
export type Game = Omit<ReturnType<typeof useGame>, 'send'> & { send: (action: Action) => void } & { inspectCopy?: (id: string | null) => void; copyOnDesk?: string | null; learning?: { openGuide: (chapter: string) => void; firstStep?: string }; useCopy?: (target: 'desk' | 'board', slot?: 0 | 1, copyId?: string) => void };
