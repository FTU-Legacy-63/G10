import { useState } from 'react';
import { GUIDE_CHAPTERS } from './HelpView';
import { ReadingPane } from './ReadingPane';
import { Arrow } from './Primitives';
import type { Game } from './types';

export function RulebookView({ game }: { game: Game }) {
  const [page, setPage] = useState(0);
  const chapter = GUIDE_CHAPTERS[page];
  return <div className="open-rulebook">
    <nav className="book-contents" aria-label="Rulebook chapters"><h3>Credit rulebook</h3><p className="fine">Contents</p>{GUIDE_CHAPTERS.map((c, i) => <button key={c.title} aria-current={page === i ? 'page' : undefined} onClick={() => setPage(i)}><span>{String(i + 1).padStart(2, '0')}</span>{c.title}</button>)}</nav>
    <div className="book-spine" aria-hidden="true" />
    <div className="book-page"><ReadingPane game={game} id={`rulebook:${page}`} label="Rulebook page"><article className="help-view document-body" key={page}><span className="record-id">PROJECT CLASSIFICATION RULES</span><h3>{chapter.title}</h3>{chapter.content}</article></ReadingPane><div className="book-pagination"><button aria-label="Previous chapter" disabled={page === 0} onClick={() => setPage(page - 1)}><Arrow left /></button><span>{page + 1} / {GUIDE_CHAPTERS.length}</span><button aria-label="Next chapter" disabled={page === GUIDE_CHAPTERS.length - 1} onClick={() => setPage(page + 1)}><Arrow /></button></div></div>
  </div>;
}
