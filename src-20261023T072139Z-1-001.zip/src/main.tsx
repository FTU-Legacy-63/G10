import { lazy, StrictMode, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
const App = /^\/integration\/?$/.test(location.pathname)
  ? lazy(() => import('./integration/IntegrationApp'))
  : location.pathname.startsWith('/concept')
  ? lazy(() => import('./concept/ConceptApp'))
  : lazy(() => import('./LegacyEntry'));
createRoot(document.getElementById('root')!).render(<StrictMode><Suspense fallback={<p style={{ color: '#eee5d2', background: '#151613', padding: 24 }}>Loading The Credit Desk…</p>}><App /></Suspense></StrictMode>);
